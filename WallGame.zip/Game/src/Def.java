
public class Def {

	//frame
	public static final int WINDOW_WIDTH =600;
	public static final int WINDOW_HIEGHT =400;
	public static final int THREAD_SLEEP = 30;
	

	//player 
	public static final int PLAYER_WIDTH=36,
							PLAYER_HEIGHT=35;

	public static final float SPAWN_X = 130;
	public static final float SPAWN_Y = 130;
	public static final float PLAYER_SPEED=3.6f;

	public static final float PLAYER_MAXSPEED=PLAYER_SPEED*2;
	// block
	public static final int BLOCK_ARRAY=3;

	public static final double BLOCK_SPEED=1;
}
