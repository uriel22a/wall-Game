import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;
public class Block {
	
	private boolean diractionDawn = true;
	private int timesPass; // every block separately
	private double x = Def.WINDOW_WIDTH ;
	private static int level;
	public Block() {
		// TODO Auto-generated constructor stub
		 timesPass = 0;
		 level =1;
		spawn();
	}
	private void spawn() {
		timesPass ++;
		Random rnd = new Random();
		this.x = rnd.nextInt(Def.WINDOW_WIDTH)+Def.WINDOW_HIEGHT;
		diractionDawn = rnd.nextBoolean();
	}
	
	public void paint(Graphics g) {
		// TODO Auto-generated method stub
		
		g.setColor(new Color(999999999));
		if(this.timesPass > 6) {
			level =2;
			g.setColor(new Color(1111111));
			if(this.timesPass > 14) {
				level =3;
				g.setColor(new Color(timesPass*100));
			}
		}
		
		
		if(!(this.diractionDawn)) {
			g.fillRect((int) this.x, Def.WINDOW_HIEGHT /2, Def.PLAYER_WIDTH, Def.WINDOW_HIEGHT /2 + Def.PLAYER_HEIGHT);
			g.setColor(Color.black);
			g.drawRect((int) this.x, Def.WINDOW_HIEGHT /2, Def.PLAYER_WIDTH, Def.WINDOW_HIEGHT /2 + Def.PLAYER_HEIGHT);
		}else {
			g.fillRect((int) this.x, 0, Def.PLAYER_WIDTH, Def.WINDOW_HIEGHT /2 + Def.PLAYER_HEIGHT);		
			g.setColor(Color.black);
			g.drawRect((int) this.x, 0, Def.PLAYER_WIDTH, Def.WINDOW_HIEGHT /2 + Def.PLAYER_HEIGHT);
		}
	}
	
	public void move(){
		if(x <= 0) {
			x = speedLevel();
			spawn();
		}
		solidBlock();
		x-= speedLevel();
		
	}
	private double speedLevel() {
		double speed = Def.BLOCK_SPEED;
		 speed += Def.BLOCK_SPEED* (this.timesPass*0.4);
		return speed;
	}
	
	public void solidBlock() {
		if((Player.getX() == this.x )||(Player.getX() <= this.x +Def.PLAYER_WIDTH/2 )&&(Player.getX() >= this.x -Def.PLAYER_WIDTH/2 )) {
			if((this.diractionDawn) && Player.getY() <= Def.WINDOW_HIEGHT /2 +Def.PLAYER_HEIGHT)
			{	Game.stop();}
			else if((!this.diractionDawn )&& Player.getY() >= Def.WINDOW_HIEGHT /2 - Def.PLAYER_HEIGHT)
				{Game.stop();}
			}
		}
	public static int getLevel() {
		return level;
	}
	
	}
