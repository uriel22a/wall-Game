import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Graphics;


public class Window extends Canvas {

	private static Game game;
	public Window() {
		// TODO Auto-generated constructor stub
		Dimension dim = new Dimension(Def.WINDOW_WIDTH,Def.WINDOW_HIEGHT);
		this.setPreferredSize(dim);
		this.setMaximumSize(dim);
		this.setMinimumSize(dim);
		this.setVisible(true);
		this.setFocusable(false);
		game = new Game();
		game.add(this);
		game.pack();

	}
	
	
	

	
	@Override
	public void paint(Graphics g) {
		// TODO Auto-generated method stub
		super.paint(g);		
		game.paint(g);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			new Window();

	}		
	
	

}
