import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Player extends Creature implements KeyListener {
	private float speed;
	private double velX,velY;

	public Player(float x, float y, int width, int height) {
		super(x, y, width, height);
		// TODO Auto-generated constructor stub
		speed = Def.PLAYER_SPEED;
		x = Def.SPAWN_X;
		y = Def.SPAWN_Y;
		velX =0;
		velY=0;
	
	}

	public void paint(Graphics g) {
		// TODO Auto-generated method stub
		g.setColor( Color.BLACK);
		g.fillOval((int)this.x-2, (int) this.y-2, Def.PLAYER_WIDTH+4, Def.PLAYER_HEIGHT+4);
		g.setColor(new Color(102,102,102));
		g.fillOval((int)this.x, (int) this.y, Def.PLAYER_WIDTH, Def.PLAYER_HEIGHT);
	
	}


	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		int key = e.getKeyCode();

		if(key == KeyEvent.VK_S) {
			this.velY+=speed;
		}
		if(key == KeyEvent.VK_W) {
			this.velY-=speed;
		}
		if(key == KeyEvent.VK_A) {
			this.velX-=speed;
		}
		if(key == KeyEvent.VK_D) {
			this.velX+=speed;
		}
		checkPlace();
	}
	private void checkPlace() {
		// TODO Auto-generated method stub
		if(this.x <0 )
			this.x = Def.WINDOW_WIDTH;
		if(this.y <0 )
			this.y = Def.WINDOW_HIEGHT;
		if(this.x > Def.WINDOW_WIDTH )
			this.x = 0;
		if(this.y > Def.WINDOW_HIEGHT)
			this.y = 0;
	
		if(this.velX >= Def.PLAYER_MAXSPEED)
			this.velX = Def.PLAYER_MAXSPEED;
		if(this.velX <= -Def.PLAYER_MAXSPEED)
			this.velX = -Def.PLAYER_MAXSPEED;
		if(this.velY >= Def.PLAYER_MAXSPEED)
			this.velY = Def.PLAYER_MAXSPEED;
		if(this.velY <= -Def.PLAYER_MAXSPEED)
			this.velY = -Def.PLAYER_MAXSPEED;
	}

	public void move() {
		x += velX;
		y += velY;
	}
	
	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		velX =0;
		velY=0;
	}


}
