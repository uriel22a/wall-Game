import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Player extends Creature implements KeyListener {
	private float speed;
	private double velX,velY;
	private static double x;
	private static double y;
	public Player(float x, float y, int width, int height) {
		super(x, y, width, height);
		// TODO Auto-generated constructor stub
		speed = Def.PLAYER_SPEED;
		Player.x = x;
		Player.y = y;
		velX =0;
		velY=0;
	
	}

	public void paint(Graphics g) {
		// TODO Auto-generated method stub
		g.setColor( Color.BLACK);
		g.fillOval((int)Player.x-2, (int) Player.y-2, Def.PLAYER_WIDTH+4, Def.PLAYER_HEIGHT+4);
		g.setColor(new Color(102,102,102));
		g.fillOval((int)Player.x, (int) Player.y, Def.PLAYER_WIDTH, Def.PLAYER_HEIGHT);
	
	}


	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		int key = e.getKeyCode();

		if(key == KeyEvent.VK_S) {
			this.velY+=speed;
		}
		if(key == KeyEvent.VK_W) {
			this.velY-=speed;
		}
		if(key == KeyEvent.VK_A) {
			this.velX-=speed;
		}
		if(key == KeyEvent.VK_D) {
			this.velX+=speed;
		}
		checkPlace();
	}
	private void checkPlace() {
		// TODO Auto-generated method stub
		if(Player.x <0 )
			Player.x = Def.WINDOW_WIDTH;
		if(Player.y <0 )
			Player.y = Def.WINDOW_HIEGHT;
		if(Player.x > Def.WINDOW_WIDTH )
			Player.x = 0;
		if(Player.y > Def.WINDOW_HIEGHT)
			Player.y = 0;
	
		if(this.velX >= Def.PLAYER_MAXSPEED)
			this.velX = Def.PLAYER_MAXSPEED;
		if(this.velX <= -Def.PLAYER_MAXSPEED)
			this.velX = -Def.PLAYER_MAXSPEED;
		if(this.velY >= Def.PLAYER_MAXSPEED)
			this.velY = Def.PLAYER_MAXSPEED;
		if(this.velY <= -Def.PLAYER_MAXSPEED)
			this.velY = -Def.PLAYER_MAXSPEED;
	}

	public void move() {
		x += velX;
		y += velY;
	}
	
	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		velX =0;
		velY=0;
	}

	public static double getX() {
		return x;
	}


	public void setX(float x) {
		Player.x = x;
	}


	public static double getY() {
		return y;
	}


	public void setY(float y) {
		Player.y = y;
	}



}
