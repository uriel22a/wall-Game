
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferStrategy;

import javax.swing.JFrame;

public class Game extends JFrame  implements KeyListener, Runnable{

	
	private Player player;
	private Block[] block = new Block[Def.BLOCK_ARRAY];
	private static Thread thread;
	private static boolean running;
	private BufferStrategy bs;
	
public static void main(String[] args) {
	new Game();
}
	public Game() {
		this.init();	
		this.player = new Player(130,130,Def.PLAYER_WIDTH,Def.PLAYER_HEIGHT);
		for (int i = 0; i < block.length; i++) {
			this.block[i] = new Block();	
		}
		start();
		run();
	}
	
	
	
	public synchronized void start() {
		//start thread
		if (running)
			return;
	
		running=true;
		thread = new Thread(this);
			thread.start();
	}
	public synchronized static void stop() {
		//stop thread 
		if(!running)
			return;
		
		running=false;
		try {
			thread.join();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	
	public void paint (Graphics graphics) {
		super.paint(graphics);
		bs = Game.super.getBufferStrategy();
		if(bs==null) {
			Game.super.createBufferStrategy(3);
			return;
			}
		
		graphics = bs.getDrawGraphics();
		//clear screen
		//graphics.setColor(Color.WHITE);
		//graphics.clearRect(0, 0, Def.WINDOW_WIDTH, Def.WINDOW_HIEGHT);
		this.player.paint(graphics);
		for (int i = 0; i < block.length; i++) {
			this.block[i].paint(graphics);
		}graphics.dispose();
		bs.show();
	}
	
	private void init() {
		
		printKeys();
		this.setLocationRelativeTo(null);
		this.setSize(Def.WINDOW_WIDTH, Def.WINDOW_HIEGHT);
		this.setResizable(false);
		this.setTitle("game");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		this.addKeyListener(this);
	}
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		player.keyPressed(e);
		
	}
	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
	player.keyReleased(e);	
	
	}
	
	private static void printKeys() {
		// TODO Auto-generated method stub
		System.out.println("----------------------");
		System.out.println("the keys are:");
		System.out.println("[W] for up");
		System.out.println("[S] for dawn");
		System.out.println("[A] for left");
		System.out.println("[D] for right");
		System.out.println("----------------------");
	}


	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		int sec = 0;
		while(running) {
			try {
				repaint();
				player.move();
				for (int i = 0; i < block.length; i++) {
					block[i].move();
				}
				repaint();
				thread.sleep(Def.THREAD_SLEEP);
				repaint();
				sec+=1;
			
				if(!running) {
					sec = (int)(sec *(Def.THREAD_SLEEP* 0.001)); // from milliseconds to seconds
					System.out.println("level : "+ Block.getLevel());
					System.out.println("end in :" + sec+" sec");	
				}
			}catch (Exception e) {
				// TODO: handle exception
			}
		}

	}
}
